<style>
    #color-buttons .btn {
        margin-right: 10px;
    }

    #size-buttons .btn {
        margin-right: 10px;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="product-image">
                <img src="http://localhost:8000/<?= $products['image'] ?>" alt="<?= $products['name'] ?>" class="img-fluid" style="max-height: 600px; object-fit: cover;">
            </div>
        </div>
        <div class="col-md-6">
            <div class="text">
                <h1 class="product-name"><?= $products['name'] ?></h1>
            </div>
            <div id="variant-info">
                <p><strong><span id="sku-info">N/A</span></strong></p>
            </div>
            <div class="product-info">
                <p><strong>Mô tả:</strong> <?= $products['description'] ?></p>
                <p><strong>Giá sản phẩm:</strong> $<span id="base-price"><?= number_format($products['price'], 2) ?></span></p>

                <div class="form-group">
                    <label><strong>Chọn màu</strong></label><br>
                    <div id="color-buttons" class="btn-group" role="group" aria-label="Color select">
                        <?php foreach ($variants as $variant): ?>
                            <input type="radio" id="color-<?= $variant['id'] ?>" name="color" class="btn-check" data-color="<?= $variant['color_name'] ?>" data-price="<?= $variant['price'] ?>" data-size="<?= $variant['size_name'] ?>" data-sku="<?= $variant['sku'] ?>" data-quantity="<?= $variant['quantity'] ?>" />
                            <label class="btn btn-outline-primary" for="color-<?= $variant['id'] ?>"><?= $variant['color_name'] ?></label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="form-group">
                    <label><strong>Chọn Size</strong></label><br>
                    <div id="size-buttons" class="btn-group" role="group" aria-label="Size select">
                        <?php foreach ($variants as $variant): ?>
                            <input type="radio" id="size-<?= $variant['id'] ?>" name="size" class="btn-check" data-color="<?= $variant['color_name'] ?>" data-price="<?= $variant['price'] ?>" data-size="<?= $variant['size_name'] ?>" data-sku="<?= $variant['sku'] ?>" data-quantity="<?= $variant['quantity'] ?>" />
                            <label class="btn btn-outline-success" for="size-<?= $variant['id'] ?>"><?= $variant['size_name'] ?></label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label><strong>Số lượng</strong></label><br>
                    <div class="input-group">
                        <button type="button" id="decrease-quantity" class="btn btn-outline-secondary">-</button>
                        <input type="text" id="quantity" class="form-control" value="1" min="1" readonly />
                        <button type="button" id="increase-quantity" class="btn btn-outline-secondary">+</button>
                    </div>
                </div>


                <div id="variant-info">
                    <p><strong>Màu Chọn:</strong> <span id="selected-color">N/A</span></p>
                    <p><strong>Size Chọn:</strong> <span id="selected-size">N/A</span></p>
                    <p><strong>Giá:</strong> $<span id="variant-price">N/A</span></p>
                    <p><strong>Số Lượng:</strong> <span id="variant-quantity">N/A</span></p>
                </div>

                <a href="/" class="btn btn-secondary mt-3">Quay lại</a>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const colorButtons = document.querySelectorAll("input[name='color']");
        const sizeButtons = document.querySelectorAll("input[name='size']");
        const quantityInput = document.getElementById("quantity");
        const decreaseButton = document.getElementById("decrease-quantity");
        const increaseButton = document.getElementById("increase-quantity");
        const variantInfo = document.getElementById("variant-info");

        function updateVariantInfo() {
            const selectedColor = document.querySelector("input[name='color']:checked");
            const selectedSize = document.querySelector("input[name='size']:checked");

            const color = selectedColor ? selectedColor.dataset.color : "N/A";
            const size = selectedSize ? selectedSize.dataset.size : "N/A";
            const price = selectedSize ? selectedSize.dataset.price : selectedColor ? selectedColor.dataset.price : "N/A";
            const sku = selectedSize ? selectedSize.dataset.sku : selectedColor ? selectedColor.dataset.sku : "N/A";
            const quantity = selectedColor && selectedSize ? Math.min(selectedColor.dataset.quantity, selectedSize.dataset.quantity) : "N/A"; // Ensure both color and size quantity are considered

            document.getElementById("selected-color").textContent = color;
            document.getElementById("selected-size").textContent = size;
            document.getElementById("variant-price").textContent = price;
            document.getElementById("variant-quantity").textContent = quantity;
            document.getElementById("sku-info").textContent = sku;

            const selectedQuantity = quantityInput.value;
            document.getElementById("variant-quantity").textContent = selectedQuantity;
        }

        colorButtons.forEach(button => button.addEventListener("change", updateVariantInfo));
        sizeButtons.forEach(button => button.addEventListener("change", updateVariantInfo));

        decreaseButton.addEventListener("click", function() {
            let currentQuantity = parseInt(quantityInput.value);
            if (currentQuantity > 1) {
                quantityInput.value = currentQuantity - 1;
                updateVariantInfo();
            }
        });

        increaseButton.addEventListener("click", function() {
            let currentQuantity = parseInt(quantityInput.value);
            quantityInput.value = currentQuantity + 1;
            updateVariantInfo();
        });

        quantityInput.addEventListener("input", updateVariantInfo);
    });
</script>