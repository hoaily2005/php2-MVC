<div class="text-center">
    <img src="https://media.istockphoto.com/id/1404059706/vector/website-page-not-found-error-404-oops-worried-robot-character-peeking-out-of-outer-space.jpg?s=612x612&w=0&k=20&c=DvPAUof9UsNuNqCJy2Z7ZLLk75qDA3bbLXOOW_50wAk=" alt="unauthorized" class="img-fluid mb-4">
    <div class="mt-3">
        <a class="btn btn-danger" href="/">Quay lại trang chủ</a>
    </div>
</div>