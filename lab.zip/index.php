<?php
require_once "controller/ProductController.php";
require_once "controller/CategoryController.php";
require_once "controller/Controller.php";
require_once "controller/AuthController.php";
require_once "controller/SizeController.php";
require_once "controller/ColorController.php";
require_once "controller/ProductVariantController.php";
require_once "controller/CartController.php";
require_once "controller/OrderController.php";
require_once "router/Router.php";
require_once "middleware.php";

$router = new Router();
$productController = new ProductController();
$categoryController = new CategoryController();
$authController = new AuthController();
$sizeController = new SizeController();
$colorController = new ColorController();
$productVariantController = new ProductVariantController();
$cartController = new CartController();
$orderController = new OrderController();
$controller = new Controller();

$router->addMiddleware('logRequest');


$router->addRoute("/", [$controller, "index"]);
$router->addRoute("/admin", [$controller, "admin"], ['checkLogin', 'checkAdmin']);
//product
$router->addRoute("/admin/products", [$productController, "index"], ['checkLogin', 'checkUserOrAdmin']);
$router->addRoute("/products/detail/{id}", [$productController, "show"]);
$router->addRoute("/admin/products/create", [$productController, "create"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/products/edit/{id}", [$productController, "edit"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/products/delete/{id}", [$productController, "delete"], ['checkLogin', 'checkAdmin']);

//Product Variant
$router->addRoute("/admin/variants/detail/{id}", [$productVariantController, "show"], ['checkLogin', 'checkUserOrAdmin']);
$router->addRoute("/admin/products/variants/create/{id}", [$productVariantController, "create"], ['checkLogin', 'checkAdmin']);
// $router->addRoute("/variants/edit/{id}", [$productVariantController, "edit"], ['checkLogin', 'checkAdmin']);
// $router->addRoute("/variants/delete/{id}", [$productVariantController, "delete"], ['checkLogin', 'checkAdmin']);

//user
$router->addRoute("/admin/users", [$authController, "indexUser"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/users/delete/{id}", [$authController, "delete"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/users/edit/{id}", [$authController, "editRole"], ['checkLogin', 'checkAdmin']);

//category
$router->addRoute("/admin/category", [$categoryController, "index"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/category/create", [$categoryController, "create"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/category/edit/{id}", [$categoryController, "edit"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/category/delete/{id}", [$categoryController, "delete"], ['checkLogin', 'checkAdmin']);

//usser
$router->addRoute("/login", [$authController, "login"]);
$router->addRoute("/register", [$authController, "register"]);
$router->addRoute("/logout", [$authController, "logout"]);
$router->addRoute("/", [$controller, "index"]);
$router->addRoute("/login/google", [$authController, "redirectToGoogle"]);
$router->addRoute("/auth/google-login", [$authController, "googleCallback"]);

//forgot password
$router->addRoute("/forgot-password", [$authController, "forgotPassword"]);
$router->addRoute("/reset-password", [$authController, "resetPassword"]);

//size
$router->addRoute("/admin/sizes", [$sizeController, "index"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/sizes/create", [$sizeController, "create"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/sizes/edit/{id}", [$sizeController, "edit"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/sizes/delete/{id}", [$sizeController, "delete"], ['checkLogin', 'checkAdmin']);

//color
$router->addRoute("/admin/colors", [$colorController, "index"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/colors/create", [$colorController, "create"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/colors/edit/{id}", [$colorController, "edit"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/colors/delete/{id}", [$colorController, "delete"], ['checkLogin', 'checkAdmin']);

//Variants
$router->addRoute("/admin/products/show_variant/{id}", [$productVariantController, "show"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/products/variants/delete/{id}", [$productVariantController, "delete"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/admin/products/variants/edit/{id}", [$productVariantController, "edit"], ['checkLogin', 'checkAdmin']);

//cart
$router->addRoute("/carts", [$cartController, "index"]);
$router->addRoute("/carts/addToCart", [$cartController, "addCart"]);
$router->addRoute("/carts/delete/{id}", [$cartController, "delete"]);
$router->addRoute("/carts/deleteAll", [$cartController, "deleteAll"]);
$router->addRoute("/carts/update", [$cartController, "update"]);

//Order
$router->addRoute("/checkout", [$orderController, "createOrder"]);
$router->addRoute("/admin/orders", [$orderController, "index"], ['checkLogin', 'checkAdmin']);
$router->addRoute("/orders/detail/{id}", [$orderController, "show"], ['checkLogin', 'checkUserOrAdmin']);
$router->addRoute("/unauthorized", [$authController, "unauthorized"]);

$router->dispatch();
?>